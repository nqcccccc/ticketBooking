<?php
    require "connect.php";

    $user = $_POST['user'];
    $pass = $_POST['pass'];

    if(strlen($user)>0 && strlen($pass)>0){
        $arrayUser = array();
        $query = "SELECT * FROM tbl_user WHERE FIND_IN_SET('$user',user) AND FIND_IN_SET('$pass',pass)";
        $data = mysqli_query($con,$query);
        if($data){
            while($row = mysqli_fetch_assoc($data)){
                $rows[] = array_map('utf8_encode', $row);
                if(count($rows)>0){
                    echo json_encode($rows);
                }else{
                    echo "No records";
                }        
            }
        }else{
            echo "Error";
        }
    }
?>