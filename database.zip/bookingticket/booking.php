<?php
    require "connect.php";

    $id_show = $_POST['id_show'];
    $movie_name = $_POST['movie_name'];
    $user_id = $_POST['user_id'];
    $seat = $_POST['seat'];
    $date = $_POST['date'];
    $qty = $_POST['qty'];
    $qr = "NULL";
    // $id_show = 1;
    // $movie_name = "THE NUN";
    // $user_id = 6;
    // $seat = "B3";
    // $date = "7/12/2020";
    // $qty = 1;
    // $qr = "NULL";


    if(strlen($seat)>0 && strlen($date)>0){
        $query = "INSERT INTO tbl_book VALUES(null,'$id_show','$movie_name','$user_id','$seat','$date','$qty','$qr')";
        $data = mysqli_query($con,$query);
        if($data){
            echo "Success";
        }else{
            echo "Fail";
        }
    }else{
        echo "Error";
    }
?>