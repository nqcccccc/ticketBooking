-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 07, 2020 at 04:54 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bookingticket`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_banner`
--

CREATE TABLE `tbl_banner` (
  `id` int(11) NOT NULL,
  `banner` varchar(255) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_banner`
--

INSERT INTO `tbl_banner` (`id`, `banner`, `status`) VALUES
(1, 'http://192.168.0.15/bookingticket/banner/slider1.jpg', 1),
(2, 'http://192.168.0.15/bookingticket/banner/slider2.jpg', 1),
(3, 'http://192.168.0.15/bookingticket/banner/slider3.jpg', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_book`
--

CREATE TABLE `tbl_book` (
  `id_book` int(11) NOT NULL,
  `id_show` int(11) NOT NULL,
  `movie_name` varchar(255) NOT NULL,
  `user_id` int(11) NOT NULL,
  `seat` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL,
  `qty` int(11) NOT NULL,
  `qr` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_book`
--

INSERT INTO `tbl_book` (`id_book`, `id_show`, `movie_name`, `user_id`, `seat`, `date`, `qty`, `qr`) VALUES
(1, 1, 'THE NUN', 6, 'A1, A2', '7/12/2020', 2, 'null'),
(2, 1, 'THE NUN', 6, 'B3', '7/12/2020', 1, 'NULL'),
(3, 6, 'IO', 6, 'A1, A2, A3, B1, B2, B3, C1, C2, C3', '9/12/2020', 9, 'NULL'),
(4, 5, 'IO', 6, 'A1', '11/12/2020', 1, 'NULL');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_movie`
--

CREATE TABLE `tbl_movie` (
  `id_movie` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `trailer` varchar(10000) NOT NULL,
  `genre` varchar(255) NOT NULL,
  `length` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL,
  `lang` varchar(255) NOT NULL,
  `des` text NOT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_movie`
--

INSERT INTO `tbl_movie` (`id_movie`, `name`, `trailer`, `genre`, `length`, `date`, `lang`, `des`, `id`) VALUES
(1, 'THE NUN', 'http://192.168.0.15/bookingticket/trailer/nun.mp4', 'Horror', '1h36', '5/9/2018', 'English', 'The Nun is a 2018 American gothic supernatural horror film directed by Corin Hardy and written by Gary Dauberman, from a story by Dauberman and James Wan. ... The plot follows a Roman Catholic priest and a nun in her novitiate as they uncover an unholy secret in 1952 Romania.', 1),
(2, 'IO', 'http://192.168.0.15/bookingticket/trailer/io.mp4', 'Sci-fi Drama', '1h36', '2019', 'English', 'As a young scientist searches for a way to save a dying Earth, she finds a connection with a man who\'s racing to catch the last shuttle off the planet.', 2),
(3, 'DORA AND THE LOST CITY OF GOLD', 'http://192.168.0.15/bookingticket/trailer/dora.mp4', 'Adventure', '1h42', '8/8/2019', 'English', 'Dora and the Lost City of Gold is a 2019 American adventure comedy film that is a live-action adaptation of the Nick Jr animated television series Dora the Explorer and directed by James Bobin. The film stars Isabela Moner, Eugenio Derbez, Michael Peña, with Eva Longoria, and Danny Trejo as the voice of Boots. The film serves as Dora\'s final send off.', 3);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_poster`
--

CREATE TABLE `tbl_poster` (
  `id` int(11) NOT NULL,
  `poster` varchar(255) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_poster`
--

INSERT INTO `tbl_poster` (`id`, `poster`, `status`) VALUES
(1, 'http://192.168.0.15/bookingticket/poster/poster1.jpeg', 1),
(2, 'http://192.168.0.15/bookingticket/poster/poster2.jpeg', 1),
(3, 'http://192.168.0.15/bookingticket/poster/poster3.jpeg', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_show`
--

CREATE TABLE `tbl_show` (
  `id` int(11) NOT NULL,
  `date` varchar(255) NOT NULL,
  `time` varchar(255) NOT NULL,
  `id_movie` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_show`
--

INSERT INTO `tbl_show` (`id`, `date`, `time`, `id_movie`) VALUES
(1, '7/12/2020', '15:30', 1),
(2, '8/12/2020', '16:30', 1),
(3, '10/12/2020', '17:30', 1),
(4, '7/12/2020', '18:30', 2),
(5, '11/12/2020', '19:30', 2),
(6, '9/12/2020', '15:30', 2),
(7, '10/12/2020', '15:30', 3),
(8, '10/12/2020', '10:30', 3),
(9, '15/12/2020', '09:30', 3);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `id` int(11) NOT NULL,
  `user` varchar(255) NOT NULL,
  `pass` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `avatar` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`id`, `user`, `pass`, `email`, `avatar`) VALUES
(6, 'cuong2000', '1234', 'cuongbo1234@gmail.com', 'http://192.168.0.15/bookingticket/user/IMG_20201205_112634_6441607159561491.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_banner`
--
ALTER TABLE `tbl_banner`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_book`
--
ALTER TABLE `tbl_book`
  ADD PRIMARY KEY (`id_book`);

--
-- Indexes for table `tbl_movie`
--
ALTER TABLE `tbl_movie`
  ADD PRIMARY KEY (`id_movie`);

--
-- Indexes for table `tbl_poster`
--
ALTER TABLE `tbl_poster`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_show`
--
ALTER TABLE `tbl_show`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user` (`user`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_banner`
--
ALTER TABLE `tbl_banner`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_book`
--
ALTER TABLE `tbl_book`
  MODIFY `id_book` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_movie`
--
ALTER TABLE `tbl_movie`
  MODIFY `id_movie` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_poster`
--
ALTER TABLE `tbl_poster`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_show`
--
ALTER TABLE `tbl_show`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
