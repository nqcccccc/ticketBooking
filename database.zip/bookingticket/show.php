<?php
    require "connect.php";

    $date = $_POST['date'];
    $id_movie = $_POST['id_movie'];

    // $date = "10/12/2020";
    // $id_movie = 1;

    $query = "SELECT * FROM tbl_show WHERE date = '$date' AND id_movie = '$id_movie'";
    $data = mysqli_query($con,$query);
    if($data){
        while($row = mysqli_fetch_assoc($data)){
            $rows[] = array_map('utf8_encode', $row);      
        }
        if (mysqli_num_rows($data) == 0) {
            echo "Clear";
        } else {
            echo json_encode($rows);
        }
    }
?>