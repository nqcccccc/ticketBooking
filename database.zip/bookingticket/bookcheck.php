<?php
    require "connect.php";

    $id_show = $_POST['id_show'];


    $query = "SELECT * FROM tbl_book WHERE id_show = '$id_show'";
    $data = mysqli_query($con,$query);
    if($data){
        while($row = mysqli_fetch_assoc($data)){
            $rows[] = array_map('utf8_encode', $row);      
        }
        if (mysqli_num_rows($data) == 0) {
            echo "Clear";
        } else {
            echo json_encode($rows);
        }
    }
?>