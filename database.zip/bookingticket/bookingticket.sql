-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 06, 2020 at 04:43 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bookingticket`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_banner`
--

CREATE TABLE `tbl_banner` (
  `id` int(11) NOT NULL,
  `banner` varchar(255) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_banner`
--

INSERT INTO `tbl_banner` (`id`, `banner`, `status`) VALUES
(1, 'http://192.168.0.15/bookingticket/banner/slider1.jpg', 1),
(2, 'http://192.168.0.15/bookingticket/banner/slider2.jpg', 1),
(3, 'http://192.168.0.15/bookingticket/banner/slider3.jpg', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_movie`
--

CREATE TABLE `tbl_movie` (
  `id_movie` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `trailer` varchar(10000) NOT NULL,
  `genre` varchar(255) NOT NULL,
  `length` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL,
  `lang` varchar(255) NOT NULL,
  `des` text NOT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_movie`
--

INSERT INTO `tbl_movie` (`id_movie`, `name`, `trailer`, `genre`, `length`, `date`, `lang`, `des`, `id`) VALUES
(1, 'THE NUN', 'https://r2---sn-8pxuuxa-nboe6.googlevideo.com/videoplayback?expire=1607257889&ei=wXrMX63-Ns6ws8IPptuNuAk&ip=2402%3A800%3A631d%3A1dfc%3A5dca%3A95ef%3A221a%3A8fa8&id=o-AL2OntwsV1QhdewR_ykYZpdOYbEsOqmePDu_zhvhpAN8&itag=247&aitags=133%2C134%2C135%2C136%2C137%2C160%2C242%2C243%2C244%2C247%2C248%2C278%2C394%2C395%2C396%2C397%2C398%2C399&source=youtube&requiressl=yes&vprv=1&mime=video%2Fwebm&ns=k2fC-vhIv5U3jQWr16_NVmoF&gir=yes&clen=2311550&dur=113.000&lmt=1577977909483313&fvip=2&keepalive=yes&c=WEB&txp=5535432&n=p4UkEff7uICjE6txh&sparams=expire%2Cei%2Cip%2Cid%2Caitags%2Csource%2Crequiressl%2Cvprv%2Cmime%2Cns%2Cgir%2Cclen%2Cdur%2Clmt&sig=AOq0QJ8wRQIgXeVKIxVCU9NqyNPd3acwx4J_lPr9gEpqcp-QsOH2MNECIQCVFghsodT8PnuCB8BvYdeTbpTsRaiyngNX70JSR2oy0w%3D%3D&ratebypass=yes&redirect_counter=1&cm2rm=sn-8pxuuxa-nbozz7l&req_id=392d24cb52f3a3ee&cms_redirect=yes&ipbypass=yes&mh=pN&mm=29&mn=sn-8pxuuxa-nboe6&ms=rdu&mt=1607236127&mv=m&mvi=2&pl=48&lsparams=ipbypass,mh,mm,mn,ms,mv,mvi,pl&lsig=AG3C_xAwRAIgECod5-DdUmsbxCz9Za4MrE7f5rsbH6mqXoOhoBkXPV4CIGT6g1hWlp0R-dINK_lFTEOZrW_TaJu5S9WVbhyfbKcO', 'Horror', '1h36', '5/9/2018', 'English', 'The Nun is a 2018 American gothic supernatural horror film directed by Corin Hardy and written by Gary Dauberman, from a story by Dauberman and James Wan. ... The plot follows a Roman Catholic priest and a nun in her novitiate as they uncover an unholy secret in 1952 Romania.', 1),
(2, 'IO', 'https://r3---sn-npoeenll.googlevideo.com/videoplayback?expire=1607257001&ei=SXfMX4X3CYPo4AKw3KSwCQ&ip=2402%3A800%3A631d%3A1dfc%3A5dca%3A95ef%3A221a%3A8fa8&id=o-APBnzJFESD_JDm-jo18KLr5bomGZX_vLgqv2apnUObH9&itag=247&aitags=133%2C134%2C135%2C136%2C137%2C160%2C242%2C243%2C244%2C247%2C248%2C278&source=youtube&requiressl=yes&vprv=1&mime=video%2Fwebm&ns=JCBeWWKJJVa8NsCdgMprYg8F&gir=yes&clen=5090139&dur=139.720&lmt=1547156251721252&fvip=6&keepalive=yes&c=WEB&txp=5535432&n=YKQmWPC7BcggauRgx&sparams=expire%2Cei%2Cip%2Cid%2Caitags%2Csource%2Crequiressl%2Cvprv%2Cmime%2Cns%2Cgir%2Cclen%2Cdur%2Clmt&sig=AOq0QJ8wRgIhAMrU3n_P2peyqkzc3mn25P7GxTSvQKM66x1mm39trftIAiEAjR2HsQIQrLewfLp43zV4EL60-iFc2jZgJ6rooA5W7CU%3D&ratebypass=yes&redirect_counter=1&cm2rm=sn-8pxuuxa-nboez7d&req_id=a51bac89061ba3ee&cms_redirect=yes&mh=DH&mm=30&mn=sn-npoeenll&ms=nxu&mt=1607235142&mv=m&mvi=3&pl=48&lsparams=mh,mm,mn,ms,mv,mvi,pl&lsig=AG3C_xAwRQIgYPlhtsv5mO-wWI7GtPlixQkO_vk4Nw5Q5YBL5n_dTUkCIQCkJyQKKgtoYUwzrAjpSawcohlQ7gLBpR-HTXtvZzTufg%3D%3D', 'Sci-fi Drama', '1h36', '2019', 'English', 'As a young scientist searches for a way to save a dying Earth, she finds a connection with a man who\'s racing to catch the last shuttle off the planet.', 2),
(3, 'DORA AND THE LOST CITY OF GOLD', 'https://r7---sn-8pxuuxa-nbod.googlevideo.com/videoplayback?expire=1607257920&ei=4HrMX7fSEJCQlQTmkZCIDQ&ip=2402%3A800%3A631d%3A1dfc%3A5dca%3A95ef%3A221a%3A8fa8&id=o-AJno1zz1HpbaLu-NEDk96RzRszQ3Glonh5PuHR2uu37x&itag=247&aitags=133%2C134%2C135%2C136%2C137%2C160%2C242%2C243%2C244%2C247%2C248%2C278&source=youtube&requiressl=yes&vprv=1&mime=video%2Fwebm&ns=84aOVkToymYuGvPxEjVd0icF&gir=yes&clen=14792930&dur=93.176&lmt=1573319176073755&fvip=7&keepalive=yes&c=WEB&txp=5431432&n=Ajj-S5nhmYSkQx7Ck&sparams=expire%2Cei%2Cip%2Cid%2Caitags%2Csource%2Crequiressl%2Cvprv%2Cmime%2Cns%2Cgir%2Cclen%2Cdur%2Clmt&sig=AOq0QJ8wRAIgbL-yupQQREbG0GhgUa4NZxfoF3IBFvEQb62FWZ9kDuYCIE85goAo-MLPEiatLouIXnwEBNdhamIJw3yC_DW2U0bV&ratebypass=yes&redirect_counter=1&cm2rm=sn-8pxuuxa-nbozz7r&req_id=6e059eb985b6a3ee&cms_redirect=yes&ipbypass=yes&mh=7y&mm=29&mn=sn-8pxuuxa-nbod&ms=rdu&mt=1607236127&mv=m&mvi=7&pcm2cms=yes&pl=48&lsparams=ipbypass,mh,mm,mn,ms,mv,mvi,pcm2cms,pl&lsig=AG3C_xAwRAIgYbf7FTvwN9Kh0-xWO8LxFTTjIXZNaplMCklXHxoRY3ACIA7X60698X23iE7QLkq7Guqf4UImFgvm1izsQqC6fxio', 'Adventure', '1h42', '8/8/2019', 'English', 'Dora and the Lost City of Gold is a 2019 American adventure comedy film that is a live-action adaptation of the Nick Jr animated television series Dora the Explorer and directed by James Bobin. The film stars Isabela Moner, Eugenio Derbez, Michael Peña, with Eva Longoria, and Danny Trejo as the voice of Boots. The film serves as Dora’s final send off.', 3);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_poster`
--

CREATE TABLE `tbl_poster` (
  `id` int(11) NOT NULL,
  `poster` varchar(255) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_poster`
--

INSERT INTO `tbl_poster` (`id`, `poster`, `status`) VALUES
(1, 'http://192.168.1.5/bookingticket/poster/poster1.jpeg', 1),
(2, 'http://192.168.1.5/bookingticket/poster/poster2.jpeg', 1),
(3, 'http://192.168.1.5/bookingticket/poster/poster3.jpeg', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_show`
--

CREATE TABLE `tbl_show` (
  `id` int(11) NOT NULL,
  `date` varchar(255) NOT NULL,
  `time` varchar(255) NOT NULL,
  `id_movie` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_show`
--

INSERT INTO `tbl_show` (`id`, `date`, `time`, `id_movie`) VALUES
(1, '7/12/2020', '15:30', 1),
(2, '8/12/2020', '16:30', 1),
(3, '10/12/2020', '17:30', 1),
(4, '7/12/2020', '18:30', 2),
(5, '11/12/2020', '19:30', 2),
(6, '9/12/2020', '15:30', 2),
(7, '10/12/2020', '15:30', 3),
(8, '10/12/2020', '10:30', 3),
(9, '15/12/2020', '09:30', 3);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `id` int(11) NOT NULL,
  `user` varchar(255) NOT NULL,
  `pass` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `avatar` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`id`, `user`, `pass`, `email`, `avatar`) VALUES
(6, 'cuong2000', '1234', 'cuongbo1234@gmail.com', 'http://192.168.1.5/bookingticket/user/IMG_20201205_112634_6441607159561491.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_banner`
--
ALTER TABLE `tbl_banner`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_movie`
--
ALTER TABLE `tbl_movie`
  ADD PRIMARY KEY (`id_movie`);

--
-- Indexes for table `tbl_poster`
--
ALTER TABLE `tbl_poster`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_show`
--
ALTER TABLE `tbl_show`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user` (`user`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_banner`
--
ALTER TABLE `tbl_banner`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_movie`
--
ALTER TABLE `tbl_movie`
  MODIFY `id_movie` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_poster`
--
ALTER TABLE `tbl_poster`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_show`
--
ALTER TABLE `tbl_show`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
