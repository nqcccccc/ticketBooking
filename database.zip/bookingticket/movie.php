<?php
    require "connect.php";

    $id = $_POST['id'];

    $query = "SELECT * FROM tbl_movie WHERE id = '$id'";
    $data = mysqli_query($con,$query);
    if($data){
        while($row = mysqli_fetch_assoc($data)){
            $rows[] = array_map('utf8_encode', $row);      
        }
        if (mysqli_num_rows($data) == 0) {
            echo "Empty";
        } else {
            echo json_encode($rows);
        }
    }
?>