<?php
    require "connect.php";

    // $status =$_POST['status']
    $status =1 ;

    $query = "SELECT * FROM tbl_poster WHERE status = '$status'";
    $data = mysqli_query($con,$query);
    if($data){
        while($row = mysqli_fetch_assoc($data)){
            $rows[] = array_map('utf8_encode', $row);      
        }
        if(count($rows)>0){
            echo json_encode($rows);
        }else{
            echo "No records";
        }  
    }
?>