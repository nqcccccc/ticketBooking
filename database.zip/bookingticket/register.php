<?php
    require "connect.php";

    $user = $_POST['user'];
    $pass = $_POST['pass'];
    $email = $_POST['email'];
    $avatar = $_POST['avatar'];


    if(strlen($user)>0 && strlen($pass)>0 && strlen($email)>0 && strlen($avatar)> 0){
        $query = "INSERT INTO tbl_user VALUES(null,'$user','$pass','$email','$avatar')";
        $data = mysqli_query($con,$query);
        if($data){
            echo "Success";
        }else{
            echo "Fail";
        }
    }else{
        echo "Error";
    }
?>