<?php
    $hostname = "localhost";
    $username = "root";
    $password = "";
    $database = "BookingTicket";

    $con = mysqli_connect($hostname,$username,$password,$database);
?>